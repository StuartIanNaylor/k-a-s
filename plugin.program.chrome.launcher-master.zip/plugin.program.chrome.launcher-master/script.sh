#!/bin/bash
openbox &
/usr/bin/google-chrome-stable "$@"
kill %1